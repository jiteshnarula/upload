class Inventory{
    getUsetIn(){
        console.log("Inventory.getUserIn() called")
    }

    getUserOut(){
        console.log("Inventory.getUserOut() called")
    }
} // end of Inventory class


class User extends Inventory{
    constructor(uId,uName,uAge,uCity){
        super();
        this._uId_ = uId;
        this._uName_ = uName;
        this._uAge_ = uAge;
        this._uCity_ = uCity;
    }

    //override
    getUserIn(){
        console.log("User.getUserIn() called");
    }

    //override
    getUserOut(){
        console.log("User.getUserOut() called");
    }

    printingAllTheUsers(){
        let allUser = {};
        allUser.uId = this._uId_;
        allUser.uName = this._uName_;
        allUser.uAge = this._uAge_;
        allUser.uCity = this._uCity_;
        return allUser;
    }
}// end of user class


    ///creatig object of User class
    var userObject1 = new User(1002,"rahul",19,"Mumbai");
    var userObject2 = new User(1003,"Ram",66,"pune");
    var userObject3 = new User(1001,"Penny",32,"Delhi");
    var userObject4 = new User(1000,"Sheldon",30,"Delhi");

    //calling getUserIn() and getUserOut() method..
    userObject1.getUserIn();
    userObject1.getUserOut();

    //printing all the user one by one
    console.log(userObject1.printingAllTheUsers());
    console.log(userObject2.printingAllTheUsers());
    console.log(userObject3.printingAllTheUsers());
    console.log(userObject4.printingAllTheUsers());
   

//creating map object
    let allUser = new Map();

    //adding all of them in a Map
        allUser.set(1,userObject1);
        allUser.set(2,userObject2);
        allUser.set(3,userObject3);
        allUser.set(4,userObject4);
        
    //printing all the users at once

    console.log("Printing all the users at once using for loop")
    for(var [k,v] of allUser){
        console.log(allUser.get(k).printingAllTheUsers());
    }



     console.log("Printing in Ascending Order");

    //(a).... adding all the objects in the Map
    
        let sortedMap = Array.from(allUser).sort((a,b)=>a[1]._uAge_ - b[1]._uAge_);
        for(var [k,v] of sortedMap){
             console.log(allUser.get(k).printingAllTheUsers());
        }

    

    //(b).... updating all the objects in the Map
 
 
 
           
            let userID = parseInt(prompt("Enter product id"));
         var updateProduct = 
            Array.from(allUser).find(p => p[1]._uId_ === userID); 
            if(updateProduct== undefined){

                console.log("user doesnot exist");

         }else{
                updateProduct[1]._uName_ = "Lenovo";
                for(var [k,v] of sortedMap){
                    console.log(allUser.get(k).printingAllTheUsers());
               }
            }
            
     

  
    
        //(c).... Deleting the objects from the Map

        
        
    
      
                 userID = parseInt(prompt("Enter product id"));
            var deleteUser = 
                Array.from(allUser).find(p => p[1]._uId_ === userID);
                allUser.delete(deleteUser[0]);
                alert("delete done");
            
     
//printing deleting rest of the objects after deletion
        console.log("Deleting done....")
             for(var [k,v] of allUser){
                 console.log(allUser.get(k).printingAllTheUsers());
            }






