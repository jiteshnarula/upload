class Inventory {
    getUsetIn(){
        console.log("Inventory.getUserIn() called");
    }
    getUserOut(){
        console.log("Inventory.getUserOut() called" )
    }
}

class User extends Inventory{
    constructor(uID,uName,uAge,uCity){
        super();
        this._uID_ = uID;
        this._uName_ = uName;
        this._uAge_ = uAge;
        this._uCity_ = uCity;
    }    

    printingAllTheUsers(){
        var userObject = {};
        userObject.uID = this._uID_;
        userObject.uName = this._uName_;
        userObject.uAge = this._uAge_;
        userObject.uCity = this._uCity_;
        return userObject;
    }
}


//creatig user object
var userObject1 = new User(1002,"rahul",19,"Mumbai");
var userObject2  = new User(1003,"Ram",66,"Pune");
var userObject3 = new User(1001,"Penny",32,"Delhi");
var userObject4  = new User(1000,"Sheldon",30,"Delhi");


    let array = [];
    array.push(userObject1);
    array.push(userObject2);
    array.push(userObject3);
    array.push(userObject4);

    //printing all the users one by one
    console.log("User one by one");
    console.log(userObject1);
    console.log(userObject2);
    console.log(userObject3);
    console.log(userObject4);

    //printing all at once
    console.log("All at once");

    for(var user in array){
        console.log(array[user].printingAllTheUsers());
    }
    

    // arranging in ascending order
    console.log("Arranging in Ascending order");

    let sortedSet  = array.sort((a,b)=>a._uAge_ - b._uAge_);


    for(var user in array){
        console.log(array[user].printingAllTheUsers());
    }

 
    // Updating the objects
    console.log("Updating the objects");
    let userID = parseInt(prompt("Enter User ID"));

    var updateProduct = Array.from(array).find(p=> p._uID_ === userID);

    if(updateProduct == undefined){
        console.log("User Doesnot Exist");
    }else{
        updateProduct._uName_ = "Lenovo"

        for(var user in array){   
            console.log(array[user].printingAllTheUsers());
        }
    }


    //deleting the objects
    console.log("deleted Product");
    let userDeletingID = parseInt(prompt("Enter product id"));

    if(userDeletingID == undefined){
        console.log("User Doesnot Exist");
    }else{
        let deletedProduct = 
        Array.from(array).find(p=> p._uID_ === userDeletingID);
        array.splice(deletedProduct,1);
    
    
        for(var user in array){
            console.log(array[user].printingAllTheUsers());
        }
    }

    








