import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
import {TaskService} from '../../services/task.service' 
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-list-todo',
  templateUrl: './list-todo.component.html',
  styleUrls: ['./list-todo.component.css']
})
export class ListTodoComponent implements OnInit {

  constructor( private router:Router,private taskService:TaskService,private http:HttpClient) { }
  recordsLeft:boolean = true;
  allTask:object={};
  leftTask:any=[];
  ngOnInit() {
    if(localStorage.getItem("username") ==null){
      this.router.navigate(['/login-page'])
    }else{
      //call list todo items
      this.getAllTask();
    }
  }

  getAllTask(){
    this.taskService.getAllTask().subscribe(displayTask =>{ this.allTask = displayTask
    this.leftTask = this.allTask;
      if(parseInt(this.leftTask.length)==0){
        this.leftTask = !this.leftTask;
    }
  }) ;
    
  }
  deleteStudent(id){
    if(confirm("Are you sure you want to delete?")){
    this.taskService.delteTask(id).subscribe(()=> this.getAllTask())
    alert("Deleted Successfully");
    }
  }
  logOff(){
    if(confirm("Are you sure you want to Logout?")){
    localStorage.removeItem("username");
    localStorage.removeItem("password");
    this.router.navigate(['/login-page'])
    }
  }
}
