import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  submitted:boolean=false;
  constructor(private router:Router) { }

  ngOnInit() {
  }

  onSubmit(loginForm){
    this.submitted = true;
    let email = localStorage.getItem("username");
    let password = localStorage.getItem("password");


    if( loginForm.email==email && loginForm.password==password){
      this.router.navigate(['/list-todo-page'])
      localStorage.setItem("username",email);
    }else{
      alert("Please enter valid credentials");
    }
  }

  
}
