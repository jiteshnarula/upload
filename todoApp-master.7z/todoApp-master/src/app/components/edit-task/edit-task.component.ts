import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TaskService } from 'src/app/services/task.service';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {

  id:number;
  totalTask:any={} ;
  matchedData :object ={};
  updateTaskObject:object=                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      {};

  constructor(private activatedRoute:ActivatedRoute,private router:Router,
    private taskService :TaskService) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params=>{
        this.id = +params['id']
    });
    console.log("id here",this.id);
    this.taskService.getAllTask().subscribe(displayTask => {this.totalTask = displayTask
    console.log(this.totalTask);

    for(let i =0 ; i<this.totalTask.length; i++){
      if(this.totalTask[i].id === this.id){
        console.log(this.id);
        this.matchedData = this.totalTask[i];
    }

  }
}); 
}

updateTask(updateTaskObject){

this.updateTaskObject={
  "name":updateTaskObject.taskName,
  "status":updateTaskObject.taskStatus
}
console.log(this.updateTaskObject);

this.taskService.updateTask(this.updateTaskObject,this.id).subscribe(()=>this.router.navigate(["/list-todo-page"]))

}


}