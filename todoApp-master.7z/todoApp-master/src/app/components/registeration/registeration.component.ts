import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registeration',
  templateUrl: './registeration.component.html',
  styleUrls: ['./registeration.component.css']
})
export class RegisterationComponent implements OnInit {
  submitted:boolean=false;
  constructor(private router:Router) { }

  ngOnInit() {
  }

  onSubmit(registerationForm){
    this.submitted = true;
    let email = registerationForm.email;
    let password = registerationForm.password;
       this.router.navigate(['/login-page'])
      localStorage.setItem("username",email);
      localStorage.setItem("password",password);
  }
}
