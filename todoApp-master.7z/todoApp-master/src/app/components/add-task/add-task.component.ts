import { Component, OnInit } from '@angular/core';
import {TaskService} from '../../services/task.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  addTaskObject:object={};
  constructor(private taskService:TaskService,private router:Router) { }

  ngOnInit() {
    if(localStorage.getItem("username") ==null){
      this.router.navigate(['/login-page'])
    } 

  }
  addTask(task){
    this.addTaskObject={
      "name": task.taskName,
      "status": task.taskStatus
    }
  this.taskService.addTask(this.addTaskObject).subscribe(task =>{ 
    alert("Added Successfully");
    this.router.navigate(['list-todo-page'])
                                                              })

  }

}
