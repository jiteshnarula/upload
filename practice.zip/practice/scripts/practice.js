class Inventory {

    getUserIn(){
        console.log("user has logged in Inventory");
    }

    getUsetOut(){
        console.log("User has logged out from Inventory1");
    }

}



class User extends Inventory{
    constructor(uId,uName,uAge,uCity){
        super()
        this._uId_ = uId;
        this._uName_ = uName;
        this._uAge_ = uAge;
        this._uCity_ = uCity;
    }

     getUserIn(){
         console.log("user has logged in");
     }

     getUsetOut(){
         console.log("User has logged out");
     }
}


  
var user = new User(1002,"rahul",19,"Mumbai");
var user2 = new User(1003,"ram",66,"Pune");
var user3 = new User(1001,"penny",32,"Delhi");
var user4 = new User(1000,"Sheldon",30,"Delhi");


var array=[];

array.push(user);
array.push(user2);
array.push(user3);
array.push(user4);

// for(var i=0;i<array.length;i++){

    console.log(array[0]._uId_)
 




console.log("Acessending Order")



for (c = 0; c < ( array.length - 1 ); c++) {
    for (d = 0; d < array.length - c - 1; d++) {
      if (array._uId_[d] < array_uId_[d+1]) /* For descending order use < */
      {
        swap       = array.uId_[d];
        array._uId_[d]   = array._uId_[d+1];
        array._uId_[d+1] = swap;
      }
    }
  }


  for(k of array){

    console.log(k + "----"+array[k])

  }



user.getUserIn();
user.getUsetOut();