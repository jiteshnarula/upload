import React, { Component } from 'react';
import './App.css';

import Chatroom from './Chatroom.js';
import ChatPeople from './ChatPeople';

class App extends Component {
  render() {
    return (
      <div className="App">
        <ChatPeople />
        <Chatroom />
      </div>
    );
  }
}

export default App;
