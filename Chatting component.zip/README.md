This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

## Demo
![Image of Screenshot](http://i.imgur.com/cpjqXmn.png)

[http://react-chatapp.surge.sh/](http://react-chatapp.surge.sh/)

