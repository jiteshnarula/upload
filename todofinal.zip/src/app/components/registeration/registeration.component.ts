import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaskService } from 'src/app/services/task.service';

@Component({
  selector: 'app-registeration',
  templateUrl: './registeration.component.html',
  styleUrls: ['./registeration.component.css']
})
export class RegisterationComponent implements OnInit {
  submitted:boolean=false;
  taskObject:object={};
  registerationData:any={};
  matchedData:object={}
  existed:boolean = false;

  constructor(private router:Router,private taskService : TaskService) { }

  ngOnInit() {
    
    this.taskService.getRegisterationData().subscribe(regDta => {this.registerationData = regDta})

  }
  
  onSubmit(registerationForm){
    this.submitted = true;
    let email = registerationForm.email;
    let password = registerationForm.password;
 
    // console.log(this.registerationData);
    for(let i=0;i<this.registerationData.length;i++){    
      if(this.registerationData[i].email == email){
          this.existed = true;
          break;
      }else{
        this.existed = false;
      }
    }

 if(this.existed){
  alert("Email already exist please try to Login")
  this.router.navigate(['/login-page'])
}else{
  this.taskObject={
    "email":email,
    "password":password 
    }

  this.taskService.addRegisterationData(this.taskObject).subscribe(task =>{
        alert("Registeration Success!");
        this.router.navigate(['/login-page'])
  });
}

    


      // localStorage.setItem("username",email);
      // localStorage.setItem("password",password);
  }

}
