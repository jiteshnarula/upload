import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { TaskService } from 'src/app/services/task.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  submitted:boolean=false;
  registerationData:any={}
  existed:boolean=false;
  
  constructor(private router:Router,private taskService:TaskService) { }

  ngOnInit() {
    this.taskService.getRegisterationData().subscribe(regDta => {this.registerationData = regDta})
  }


  onSubmit(loginForm){
//     this.submitted = true;
//     let email = loginForm.email;
//     let password = loginForm.password;
//     console.log(this.registerationData)
//     for(let i=0;i<this.registerationData.length;i++){  
//       console.log("type of regdata email"+ typeof(this.registerationData[i].email))
//       console.log("Type of entered email"+typeof(email)) 
//       console.log("Type of reg data password" + typeof(this.registerationData[i].password ))
//       console.log("Type of entered password"+typeof(password)) 
//        console.log("reg email"+ this.registerationData[i].email);
//        console.log("email"+email)
//        console.log("reg email"+ this.registerationData[i].password);
//        console.log("password"+password)
       
       
//       if((this.registerationData[i].email === email) && this.registerationData[i].password === password){

//         this.flag == true;
//         break;
//       }else{
//         this.flag = false;
//       }
//     }

//     console.log(this.flag)
//  if(this.flag){
//         this.router.navigate(['/list-todo-page'])
//         localStorage.setItem("username",email);
// }else{
//   alert("Please enter valid credentials");
    
// }


this.submitted = true;
    let email = loginForm.email;
    let password = loginForm.password;
 
    // console.log(this.registerationData);
    for(let i=0;i<this.registerationData.length;i++){    
      if(this.registerationData[i].email == email){
          this.existed = true;
          break;
      }else{
        this.existed = false;
      }
    }

 if(this.existed){ 
  this.router.navigate(['/list-todo-page'])
  localStorage.setItem("username",email);
}else{
    
  alert("Please enter valid credentials");
}



  
}
}