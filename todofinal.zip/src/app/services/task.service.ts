import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  httpOptions={
    headers:new HttpHeaders({
              'content-type' : 'application/json'
    })
  };
  url="http://localhost:4444/todo-task";
  constructor(private http:HttpClient) { }


  getAllTask(){
   return  this.http.get(`${this.url}`);
  }

  delteTask(id){
    return this.http.delete(`${this.url}/${id}`,this.httpOptions);
  }

  addTask(taskObject){
    return this.http.post(`${this.url}`,taskObject);
  }

  updateTask(taskObj,id){
    return this.http.put(`${this.url}/${id}`,JSON.stringify(taskObj),this.httpOptions)
  }

  
  url2="http://localhost:4444/registeration";
 
  getRegisterationData(){
    return this.http.get(`${this.url2}`);
  }
  addRegisterationData(empObject){
    return this.http.post(`${this.url2}`,empObject);
  }
}
