import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { ListTodoComponent } from './components/list-todo/list-todo.component';
import { AddTaskComponent } from './components/add-task/add-task.component';
import { EditTaskComponent } from './components/edit-task/edit-task.component';
import { RegisterationComponent } from './components/registeration/registeration.component';

const routes: Routes = [
  {path:'',redirectTo:"home-page",pathMatch:"full"},
  {path:"registeration-page",component:RegisterationComponent},
  {path:"home-page",component:HomeComponent},
  {path:"login-page",component:LoginComponent},
  {path:"list-todo-page",component:ListTodoComponent},
  {path:"add-task-page",component:AddTaskComponent},
  {path:"edit-task-page/:id",component:EditTaskComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
