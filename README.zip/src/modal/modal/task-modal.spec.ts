import { TaskModal } from './task-modal';

describe('TaskModal', () => {
  it('should create an instance', () => {
    expect(new TaskModal()).toBeTruthy();
  });
});
