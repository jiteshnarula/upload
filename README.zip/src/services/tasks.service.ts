import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TasksService {

   httpOptions={
    headers:new HttpHeaders({
              'content-type' : 'application/json'
    })
  };
  constructor(private http:HttpClient) { }

  url2="http://localhost:4444/todo-task";
  


  getTaskList(){
    return this.http.get(`http://localhost:4444/todo-task`);
  }

    deleteTask(id){
    return this.http.delete(`${this.url2}/${id}`,this.httpOptions);      
  }
  updateTask(taskObject,id){
    console.log(taskObject+"-->"+id)
    return this.http.put(`${this.url2}/${id}`,JSON.stringify(taskObject),this.httpOptions);      
  }

}