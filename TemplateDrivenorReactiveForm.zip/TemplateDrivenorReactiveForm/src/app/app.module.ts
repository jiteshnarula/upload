import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { AngularDemoComponent } from "./angular-demo/angular-demo.component";
import { EmployeeComponent } from "./angular-demo/employee/employee.component";
import { EmployeeListComponent } from "./angular-demo/employee-list/employee-list.component";
import { AssignmentComponent } from "./angular-demo/assignment/assignment.component";
import { EmpgenderPipe } from "./pipe/empgender.pipe";
import { HomeComponent } from "./angular-demo/home/home.component";
import { AboutComponent } from "./angular-demo/about/about.component";
import { ContactComponent } from "./angular-demo/contact/contact.component";
import { NavBarComponent } from "./angular-demo/nav-bar/nav-bar.component";
import { PageNotFoundComponent } from "./angular-demo/page-not-found/page-not-found.component";
import { EventComponent } from "./angular-demo/event/event.component";
import { TemplateDrivenComponent } from "./angular-demo/template-driven/template-driven.component";
import { ReactiveComponent } from "./angular-demo/reactive/reactive.component";
import { LoginComponent } from "./angular-demo/login/login.component";
import { ProductComponent } from "./angular-demo/product/product.component";
import { ParentComponent } from './angular-demo/parent/parent.component';
import { ChildComponent } from './angular-demo/child/child.component';

@NgModule({
  declarations: [
    AppComponent,
    AngularDemoComponent,
    EmployeeComponent,
    EmployeeListComponent,
    AssignmentComponent,
    EmpgenderPipe,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    NavBarComponent,
    PageNotFoundComponent,
    EventComponent,
    TemplateDrivenComponent,
    ReactiveComponent,
    LoginComponent,
    ProductComponent,
    ParentComponent,
    ChildComponent
  ],
  imports: [BrowserModule, AppRoutingModule, FormsModule, ReactiveFormsModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
