import { EmpgenderPipe } from './empgender.pipe';

describe('EmpgenderPipe', () => {
  it('create an instance', () => {
    const pipe = new EmpgenderPipe();
    expect(pipe).toBeTruthy();
  });
});
