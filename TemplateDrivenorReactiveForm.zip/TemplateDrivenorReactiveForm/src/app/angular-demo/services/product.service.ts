import { Injectable } from "@angular/core";
import { Product } from "src/app/Module/product";

@Injectable({
  providedIn: "root"
})
export class ProductService {
  products: Product[] = [
    { id: 11, name: "tushar", cost: 2542, category: "Electronics" },
    { id: 12, name: "shray", cost: 500, category: "Cs" },
    { id: 13, name: "rishabh", cost: 54524, category: "IT" },
    { id: 14, name: "jivesh", cost: 235, category: "Gen" }
  ];

  getProduct() {
    return this.products;
  }

  addProducts(id: number, name: string, cost: number, category: string) {
    let obj = {
      id: id,
      name: name,
      cost: cost,
      category: category
    };
    return this.products.push(obj);
  }
  deleteProducts(products: Product) {
    let indexposition = this.products.indexOf(products);
    this.products.splice(indexposition, 1);
  }
  updateProduct(id, name, cost, category) {
    let index = 0;
    for (let prod of this.products) {
      if (prod.id == id) {
        prod.name = name;
        prod.cost = cost;
        prod.category = category;
      }
      index++;
    }
  }

  constructor() {}
}
