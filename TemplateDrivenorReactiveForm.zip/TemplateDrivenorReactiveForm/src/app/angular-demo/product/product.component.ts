import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { ProductService } from "../services/product.service";
import { Product } from "src/app/Module/product";

@Component({
  selector: "app-product",
  templateUrl: "./product.component.html",
  styleUrls: ["./product.component.css"]
})
export class ProductComponent implements OnInit {
  product: Product[] = [];
  constructor(private prodservice: ProductService) {}

  ngOnInit() {
    this.product = this.prodservice.getProduct();
  }
  addProductToService(id, name, cost, category) {
    this.prodservice.addProducts(id, name, cost, category);
  }
  deleteProductToService(products: Product) {
    this.prodservice.deleteProducts(products);
  }
  @ViewChild("id") prodidInput: ElementRef;
  @ViewChild("name") prodnameInput: ElementRef;
  @ViewChild("cost") prodcostInput: ElementRef;
  @ViewChild("category") prodcategoryInput: ElementRef;

  clearTextboxes() {
    this.prodidInput.nativeElement.value = "";
    this.prodnameInput.nativeElement.value = "";
    this.prodcostInput.nativeElement.value = "";
    this.prodcategoryInput.nativeElement.value = "";
  }
  updateFromService(id, name, cost, category) {
    this.prodservice.updateProduct(id, name, cost, category);
  }
}
