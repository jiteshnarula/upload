import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor() { }
    employee: any[] = [
       {
         code: "emp101", name:"tushar", gender: "male",
         annualSalary: 250000, dateOfBirth : '01/15/2018'
       },
       {
         code: "emp102", name:"shray", gender: "male",
         annualSalary: 350000, dateOfBirth : '05/03/1985'
       },
       {
         code: "emp103", name:"rishab", gender: "male",
         annualSalary: 450000, dateOfBirth : '11/11/1995'
       },
       {
        code: "emp104", name:"anuja", gender: "female",
        annualSalary: 450000, dateOfBirth : '03/03/1995'
      }
    ]
  

  ngOnInit() {
  }
  
}
