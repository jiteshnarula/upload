import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-demo',
  templateUrl: './angular-demo.component.html',
  styleUrls: ['./angular-demo.component.css']
})
export class AngularDemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
