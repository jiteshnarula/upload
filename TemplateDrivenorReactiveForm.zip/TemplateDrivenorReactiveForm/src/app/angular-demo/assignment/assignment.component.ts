import { Component, OnInit } from "@angular/core";
import { Product } from "src/app/Module/product";

@Component({
  selector: "app-assignment",
  templateUrl: "./assignment.component.html",
  styleUrls: ["./assignment.component.css"]
})
export class AssignmentComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
  Subjects: string[] = ["Angular", "MongoDb", "XpressJs"];

  showFaculty: boolean = false;
  Faculty: string = "Tushar Rikhe";

  duration: number = 30;
  isValid: boolean = true;

  //Object

  pro: Product = {
    id: 11,
    name: "tushar",
    cost: 4534534,
    category: "Electronics"
  };

  //Array

  products: Product[] = [
    { id: 11, name: "tushar", cost: 2542, category: "Electronics" },
    { id: 12, name: "shray", cost: 500, category: "Cs" },
    { id: 13, name: "rishabh", cost: 54524, category: "IT" }
  ];
}
