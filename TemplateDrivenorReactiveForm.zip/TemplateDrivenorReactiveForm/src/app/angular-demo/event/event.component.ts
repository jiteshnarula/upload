import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  ClickMe()
  {
    alert("Click me");
  }
  DeleteProduct(id:number)
  {
     alert("product to be deleted is "+id);
  }
  EditProduct(id1:number, name:string){
    alert(`product to be edited is ${id1} and ${name}`)
  }
  Student: string[] = ["Tushar", "Rishabh", "Jivesh","shray"]

  addNames(name:string)
  {
        alert(name);

        this.Student.push(name);

  }
  deleteName(name:string){
    alert('name to be deleted is ' +name);
    let indexposition = this.Student.indexOf(name);
    this.Student.splice(indexposition,1);
  }

}
