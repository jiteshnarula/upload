import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { User } from "src/app/Module/user";

@Component({
  selector: "app-reactive",
  templateUrl: "./reactive.component.html",
  styleUrls: ["./reactive.component.css"]
})
export class ReactiveComponent implements OnInit {
  form: FormGroup;

  userList: User[] = [];

  constructor() {}

  ngOnInit() {
    this.form = new FormGroup({
      name: new FormControl("", [
        Validators.required,
        Validators.pattern("[a-zA-z][a-zA-Z]+")
      ]),
      contact: new FormControl("", [
        Validators.required,
        Validators.pattern("[6-9][0-9]{9}")
      ]),
      email: new FormControl("", [
        Validators.required,
        Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$")
      ])
    });
  }
  AddUser(form) {
    this.userList.push(form.value);
    console.log(form.value);
  }
}
