export interface User{

    name : string,
    contact : number,
    email : string
}