import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./angular-demo/home/home.component";
import { AboutComponent } from "./angular-demo/about/about.component";
import { ContactComponent } from "./angular-demo/contact/contact.component";
import { EmployeeListComponent } from "./angular-demo/employee-list/employee-list.component";
import { EventComponent } from "./angular-demo/event/event.component";
import { PageNotFoundComponent } from "./angular-demo/page-not-found/page-not-found.component";
import { TemplateDrivenComponent } from "./angular-demo/template-driven/template-driven.component";
import { ReactiveComponent } from "./angular-demo/reactive/reactive.component";
import { LoginComponent } from "./angular-demo/login/login.component";
import { ProductComponent } from "./angular-demo/product/product.component";
import { AuthGuard } from "./angular-demo/guards/auth.guard";
import { ParentComponent } from './angular-demo/parent/parent.component';

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "about", component: AboutComponent, canActivate: [AuthGuard] },
  { path: "contact", component: ContactComponent, canDeactivate: [AuthGuard] },
  { path: "EmployeeList", component: EmployeeListComponent },
  { path: "event", component: EventComponent },
  { path: "template-driven", component: TemplateDrivenComponent },
  { path: "reactive", component: ReactiveComponent },
  { path: "login", component: LoginComponent },
  { path: "service", component: ProductComponent },
  { path: "parenttochild", component: ParentComponent },
  { path: "**", component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
