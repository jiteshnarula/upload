function formSubmit(frm){
 if(frm.checkValidity()){
    var title = frm.title.value;
    var name = frm.txtName.value;
    var address = frm.taAddress.value;
    var mobile = frm.txtMobile.value;
    var email = frm.txtEmail.value;
    var model = frm.type.value;
    var service = frm.rdbtn.value;
    var cost = parseFloat(frm.txtCost.value);
    var result;

    alert(title+name+address+mobile+email+model+service+cost);




    if(service == "FS"){
        alert(title +" "+name+"your total bill is"+200);
    }else if(service="BR"){
        if(model=="hb"){

            result = 0.15*cost;

        }else if(model=="sc"){
            result = 0.10 * cost;

        }else if(model =="sedan"){
              result =   0.18 * cost;
        }
        
 alert(title +" "+name+"your total bill is"+result);
    }
 }
}



function ddlFunction(frm){
    var title = frm.title.value;
    var status;
    if(title=="ms"){
        status ="Unmarried";
    }else{
        status="Married"
    }

    var finalResult = window.open("","fly","width=500,height=700");

    finalResult.document.write(`
                            <h1>
                            title=${title}
                            status=${status}</h1>
                        `)

}