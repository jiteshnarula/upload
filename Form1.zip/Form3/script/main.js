function changeCat(frm){

    var productList = {
        Electronics: ["Television","Laptop","Phone"],
        Grocery: ["Soap","Powder"]
    };

    var ddlCategory = frm.category.value;
   

    if(ddlCategory.length == 0){
        document.getElementById("product").innerHTML="<option></option>";
    }else{
        var productOptions="";
        for(categoryOptions in productList[ddlCategory]){
            productOptions +="<option>"+productList[ddlCategory][categoryOptions]+"</option>"
        }
        document.getElementById("product").innerHTML = productOptions;
        
        if(frm.product.value == "Television")
        {
            frm.txtPrice.value=20000;
        }

    }

}
