import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';
import {Router} from '@angular/router'
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  private allProducts;  
  private sub:any;

  p: number;
  constructor(private productService:ProductService,private router : Router,private activatedRoute :ActivatedRoute) { }

  ngOnInit() {
    this.getAllProducts();

    this.sub = this.activatedRoute.queryParams.subscribe(params=>{
      let totalPages = params["redirectPage"];
      this.p = totalPages
    })
    
  }

  getAllProducts(){
    this.productService.getAllProducts().subscribe(getAllProducts=>{this.allProducts=getAllProducts
       
    });
  }
  deleteProduct(id){
    var totalItems = this.allProducts.length;
    console.log(this.allProducts.length);
    if(confirm('Are you sure you want to delete?')){
      this.productService.deleteProductService(id).subscribe(()=>this.getAllProducts())
      let afterDeletingTotalItems = totalItems - 1;
      console.log(afterDeletingTotalItems)
      let totalPages = Math.ceil(afterDeletingTotalItems/5);
      console.log(totalPages)
      this.p = totalPages
    }
  }

  deleteAllProducts(){
    if(confirm('Are you sure you want to delete all the products?')){  
        for(let i =0 ;i<this.allProducts.length;i++){
          console.log(this.allProducts[i].id) 
          this.productService.deleteProductService(this.allProducts[i].id).subscribe(()=>{
            
            this.getAllProducts();
           })
        }
    } 
  }

     
 

}
