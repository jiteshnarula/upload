import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  private allProducts;
  private pager :any = {};
   pagedItems: any;


  constructor(private productService:ProductService) { }

  ngOnInit() {
    this.getAllProducts();
    
  }

  getAllProducts(){
    this.productService.getAllProducts().subscribe(getAllProducts=>{this.allProducts=getAllProducts
       
    });
  }
  deleteProduct(id){
    if(confirm('Are you sure you want to delete?')){
      this.productService.deleteProductService(id).subscribe(()=>this.getAllProducts())
    }
  }

     //setpage method

 

}
