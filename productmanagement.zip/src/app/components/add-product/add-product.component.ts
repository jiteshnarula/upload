import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  enteredProductObject:object={}
  constructor(private productService:ProductService,private router:Router) { }
  yesAdded:boolean = true;
  buttonLoading:boolean = false;
  ngOnInit() {
  }

  addProduct1(productObject){
    this.buttonLoading = true; 
    this.enteredProductObject={
      "name": productObject.name,
      "description" : productObject.description,
      "price": productObject.price
    }
     console.log(this.enteredProductObject)
    this.productService.addProductService(this.enteredProductObject).subscribe(student=>{
      this.yesAdded = true;
      this.router.navigate(['/product-list'])
    })
  }

}
