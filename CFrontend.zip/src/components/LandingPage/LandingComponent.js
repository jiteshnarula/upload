import React, { Component } from 'react'
import NavigationComponent from './NavigationComponent';
import FooteComponent from './FooterComponent';

export default class LandingComponent extends Component {
    myStyle={ 
        position: "relative",
        bottom: 0,
        padding: "1rem",
        width: "100%"
     }
  render() {
    return (
      <>
        <div>
        <NavigationComponent/> 
        <div className="row">
            <div className="col-lg-6 display-3 text-success">
                Welcome to your professional Community     
            </div>
            <div className="col-lg-5">
                <img height="280" width="600" src={require("../../assets/landinpageimage2.jpg")}/>
            </div>
        </div>
      </div> 
       
      <div style={this.myStyle}>
        <FooteComponent/>
        </div>  
    </>
    )
  }
}
