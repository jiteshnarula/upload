import React, { Component } from "react";

import Modal from "react-modal";
import {Tab,Tabs, TabList,TabPanel} from 'react-tabs'
import "react-tabs/style/react-tabs.css";

class NavigationComponent extends Component { 
  constructor() {
    super();
    this.state = {
      modalVisible: false,
      loginModalVisible : false
    };
  }

  customStyles = {
    content: {
      top: "50%",
      left: "50%",
      right: "auto",
      bottom: "auto",
      marginRight: "-50%",
      transform: "translate(-50%, -50%)"
    }
    
  }; 
  
  // TO make the modal more accessible
  componentWillMount() {
    Modal.setAppElement("body");
  }

  getJoinNowModal = e => {
    e.preventDefault();
    this.setState({
      modalVisible: !this.state.modalVisible
    });
  };

  getLoginModal = e => {
    e.preventDefault();
    this.setState({
        loginModalVisible : !this.state.loginModalVisible
    })
  }

  render() {
    return (
      <div>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
          <a className="navbar-brand text-white" href="#">
            8BitTeam
          </a>
          <img
            height="50"
            src={require("../../assets/output-onlinepngtools.png")}
          />
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav mr-auto">
              {/* <li className="nav-item active">
              <a className="nav-link text-white text-uppercase" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li className="nav-item active">
              <a className="nav-link text-white text-uppercase" href="#">Home <span class="sr-only">(current)</span></a>
            </li> */}
            </ul>
            <form className="form-inline my-2 my-lg-0">
              <button
                className="btn btn-outline-primary my-2 my-sm-0"
                type="submit"
                onClick={this.getJoinNowModal}
              >
                Join Now
              </button>{" "}
              &nbsp;&nbsp;
              <button
                className="btn btn-outline-success my-2 my-sm-0"
                type="submit" onClick={this.getLoginModal}>
                Log In
              </button>
            </form>
          </div>
        </nav>

        {/* is open is the default attribute in which we have to pass our default value */}
        <Modal
          isOpen={this.state.modalVisible}
          onRequestClose={this.getJoinNowModal}
          style={this.customStyles}
        >
            <h1 className="text-center text-danger"> Join Now</h1>
      <Tabs defaultIndex={0} onSelect={index =>console.log(index)}>
            <TabList>
              <Tab>User</Tab>
              <Tab>Organization</Tab>
            </TabList>
            <TabPanel> 
            <form align="center" >
                                       
                                       <div className="form-group">
                                           <input type="email" className="form-control text-center"
                                               placeholder="Enter Email " />
                                       </div>
                               
                               
                                  
                                       <div className="form-group">
                                           <input type="text" className="form-control text-center"
                                               placeholder="Enter Name" />
                                       </div>
                                   
                            
                              
                                 

                                       <div className="form-group">
                                           <input type="number" className="form-control text-center"
                                               placeholder="Enter Phone Number" />
                                       </div>
                                  

                              
                                 


                                       <div className="form-group">
                                           <input type="number" className="form-control text-center"
                                               placeholder="Enter Date Of Birth" />
                                       </div>
                                  

                              
                                 

                                       <div className="form-group">
                                           <input type="password" className="form-control text-center" placeholder="Enter Password" />
                                       </div>

                                       
                                        
                                           <input type="file" className="text-center btn " />
                                           

                                  

                               <div className="form-group">
                                   <input type="submit" value="Sign in" onClick={e => this.routeChangeLogin()} className="btn btn-primary" />&nbsp;
                                   <input type="submit" value="Go Back to Home" onClick={e => this.routeChangeHome()} className="btn btn-success" />

                               </div>
                               <h6>Already a user?&nbsp;
                           <button className="btn btn-link" onClick={e => this.routeChangeLogin()}> Click here</button>
                               </h6>
                           </form>
            </TabPanel>
            <TabPanel>
            <form align="center" onSubmit={this.onSubmit}>
                                 
                                         
                                            <div className="form-group">
                                                <input type="text" className="form-control text-center" placeholder="Enter Name" />
                                            </div>
                                         
                                     

                                   
                                         
                                            <div className="form-group">
                                                <input type="email" className="form-control text-center" placeholder="Enter Email " />
                                            </div>
                                        
                                     

                                    

                                    
                                         

                                            <div className="form-group">
                                                <input type="number" className="form-control text-center" placeholder="Enter GSTIN" />
                                            </div>
                                   

                                          


                                            <div className="form-group">
                                                <input type="number" className="form-control text-center" placeholder="Enter PAN" />
                                            </div>
                                       
                                  

                                   
                                            <div className="form-group">
                                                <input type="password" className="form-control text-center" placeholder="Enter MOA" />
                                            </div>
                                  

                                    
                                            <div className="form-group">
                                                <input type="text" className="form-control text-center" placeholder="Enter established year" />
                                            </div>
                                          

                                    <div className="form-group">
                                        <input type="submit" onClick={e => this.routeChangeGet()} value="Sign in" className="btn btn-primary" />&nbsp;
                                        <input type="submit" onClick={e => this.routeChangeHome()} value="Go Back to Home" className="btn btn-success" />

                                    </div>
                                    <h6>Already have an account?&nbsp;

                                    <button className="btn btn-link" onClick={e => this.routeChangeGet()}>Click Here</button>

                                    </h6>
                                </form>


            </TabPanel>
            </Tabs>
          <div className="text-center">
          <button
            className="btn btn-outline-success my-2 my-sm-0"
            type="submit"
            onClick={this.getJoinNowModal}
          >
            Cancel
          </button>
          </div>
        </Modal>

              {/* login modal */}

        <Modal
          isOpen={this.state.loginModalVisible}
          onRequestClose={this.getLoginModal}
          style={this.customStyles}
        > 
    
    <strong> <h1 className=" text-center text-danger"> Login </h1></strong>
          <form>
            
              <center>
                {/* <img src={image} align="center" width="140px" height="100px" /> */}
                  {/* <label align="left">Email:</label> */}
                <input
                  type="email"
                  ref="email"
                  placeholder="Enter Email"
                  className="form-control"
                />
                <br />
                {/* <label>Password:</label> */}
                <input
                  type="password"
                  ref="password"
                  placeholder="Enter Password"
                  className="form-control"
                />
                <br />
                <button className="btn btn-primary margin-bottom-10">
                  Login
                </button>
                &nbsp;&nbsp;&nbsp;
                <button className="btn btn-warning  ">
                  Forgot Password ?
                </button>
                <br />
                <br />
                Not a user?{" "}
                <button
                  className="btn btn-link"
                  onClick={e => this.routeChangeReg(e)}
                >
                  Sign up!
                </button>
                <br />
                <br />
              </center>
            
          </form>
          <div className="text-center">
          <button
            className="btn btn-outline-success my-2 my-sm-0"
            type="submit"
            onClick={this.getLoginModal}
          >
            Cancel
          </button>
          </div>
        </Modal>


      </div>
    );
  }
}
export default NavigationComponent;
