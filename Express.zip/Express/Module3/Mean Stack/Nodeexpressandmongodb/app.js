var express = require('express');
var mongoose = require('mongoose') 
var router  = require('./router/router')
var cors = require('cors')
var app =   express();
app.use(express.json()) 
// router.get();
// router.delete();
// router.post();
// router.put();

mongoose.connect('mongodb://localhost:27017/mongooseDB',{ useNewUrlParser: true })
mongoose.connection.on('connected',()=>{
    console.log("Mongodb is conencted on port 27017")
})

app.use(cors())
app.use('/api',router)


const port =1000;
app.listen(port,()=>{
    console.log("Hello from port ="+port);
})