var express = require('express'); 
var router = express.Router(); 
const item = require('../model/items')

// router.get();
// router.delete();
// router.post();
// router.put();
 

router.get('/root',(req,res)=>{
    res.send("Hello from root path using moongoose");
}) 



//remove
router.delete("/deleteItem/:id",(req,res)=>{
    item.remove({_id: req.params.id},(err,result)=>{
        if(err){
            res.json(err);
        }else{
            res.json(result)
        }
    })
})



//get
router.get("/getItem", (req, res) => {
    item.find({},(err, data) => {
        if (err) {
            console.log(err);
        } else {
            console.log(data);
            res.json(data);
        }
    });
});




//add
router.post("/item", (req, res) => {
    const newitem = new item({
        itemname: req.body.itemname,
        itemquantity: req.body.itemquantity,
        itembought: req.body.itembought
    });
    
    newitem.save((err, data) => {
        if (err) {
            console.log(err);
        } else {
            console.log(data);
            res.json(data);
        }
    });
});

//edit
router.put("/itemUpdate/:id",(req,res) =>{
    var alldata;
    var matcheddata={};
    flag = 0 ;
    // const newitem = new item({
    //     itemname: req.body.itemname,
    //     itemquantity: req.body.itemquantity,
    //     itembought: req.body.itembought
    // });
    // item.find({},(err, data) => {
    //     if (err) {
    //         console.log(err);
    //     } else {
    //         console.log(data);
    //         alldata = data; 
    //        console.log(alldata[1]._id)
    //         for(let i=0 ; i<alldata.length;i++){
    //             if(alldata[i]._id == req.params.id){
    //                 matcheddata = alldata[i];
    //                 flag= 1;
    //                 res.send(matcheddata)
    //             }
    //         }  

    //     if(flag==1){
    //         item.updateOne({_id:matcheddata._id},{$set:req.body},function(err,update){
    //             if(err){    
    //                 console.log(err)
    //             }else{
    //                 res.send(update)
    //             }
    //         })

    //     }else{
    //         res.send("ID not found :)");
    //     }
    // }
    // });

  
item.findByIdAndUpdate(req.params.id,req.body,function(err,post){
        if(err){
            console.log(err)
        }else{
            res.json("updated")
        }
    })
})


   
module.exports = router;