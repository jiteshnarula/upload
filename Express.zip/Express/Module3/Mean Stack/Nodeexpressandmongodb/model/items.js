const mongoose = require('mongoose');

const itemSchema = mongoose.Schema({
    itemname:{
        type : String,
        required : false
    },
    itemquantity:{
        type : Number,
        required : false
    },
    itembought:{
        type : Boolean,
        required : false
    }
})


var item = mongoose.model('items',itemSchema)

module.exports = item;