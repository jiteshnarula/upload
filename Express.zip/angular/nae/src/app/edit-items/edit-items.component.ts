import { Component, OnInit } from '@angular/core';
import { NaeService } from '../services/nae.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Route } from '@angular/compiler/src/core';
import { totalmem } from 'os';

@Component({
  selector: 'app-edit-items',
  templateUrl: './edit-items.component.html',
  styleUrls: ['./edit-items.component.css']
})
export class EditItemsComponent implements OnInit {
  
  matchedData:any= [];
  id:any;
  totalTask:any=[]
  updateTaskObject:object={}
  constructor( private naeService :NaeService,private router:Router,private activatedRoute:ActivatedRoute,private route:Router) { }
  
  
  ngOnInit() { 
         this.activatedRoute.params.subscribe(params=>{ 
             this.id = params['id'] 
         }); 
         console.log("id here",this.id); 
         this.naeService.getItems().subscribe(displayTask => {this.totalTask = displayTask 
         console.log(this.totalTask); 
     
     
         for(let i =0 ; i<this.totalTask.length; i++){ 
           if(this.totalTask[i]._id === this.id){ 
             
             this.matchedData = this.totalTask[i]; 
            console.log(this.matchedData)
            } 
     
     
       } 
     });  
     } 
    
     updateTask(updateTaskObject){ 
       
       
       this.updateTaskObject={ 
         "itemname":updateTaskObject.name, 
         "itemquantity":updateTaskObject.price,
         "itembought":updateTaskObject.bought 
       } 
       console.log(this.updateTaskObject); 
       
       
       this.naeService.updateTask(this.updateTaskObject,this.id).subscribe(()=>this.router.navigate(["/"])) 
       
       
       } 
      

}
