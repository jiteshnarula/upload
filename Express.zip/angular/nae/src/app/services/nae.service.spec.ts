import { TestBed } from '@angular/core/testing';

import { NaeService } from './nae.service';

describe('NaeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NaeService = TestBed.get(NaeService);
    expect(service).toBeTruthy();
  });
});
