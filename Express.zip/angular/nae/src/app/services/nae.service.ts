import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NaeService {

  constructor(private http:HttpClient) { }

 httpOptions={
    headers:new HttpHeaders({
              'content-type' : 'application/json'
    })
  };

  url = "http://localhost:1000/api/getItem"

  getItems(){
   return this.http.get(`${this.url}`)
  }


  url2 = "http://localhost:1000/api/item";

  postItem(object){
    console.log("in services"+object)
      return this.http.post(`${this.url2}`,object);
  }

  url3 = "http://localhost:1000/api//deleteItem"
  delteItem(id){
    return this.http.delete(`${this.url3}/${id}`);
  }

  url4="http://localhost:1000/api/itemUpdate";
  editItem(id,obj){
    return this.http.put(`${this.url4}/${id}`,JSON.stringify(obj))
  }

  url5="http://localhost:1000/api/itemUpdate"
  updateTask(taskObj,id){ 
          return this.http.put(`${this.url5}/${id}`,JSON.stringify(taskObj),this.httpOptions) 
        } 
    
}
