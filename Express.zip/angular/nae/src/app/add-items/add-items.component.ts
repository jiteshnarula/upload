import { Component, OnInit } from '@angular/core';
import { NaeService } from '../services/nae.service';

@Component({
  selector: 'app-add-items',
  templateUrl: './add-items.component.html',
  styleUrls: ['./add-items.component.css']
})
export class AddItemsComponent implements OnInit {

  constructor(private naeService:NaeService) { }

  postObject :object ={};
  ngOnInit() {
  }
  onSubmit(frmObj){
   let name =frmObj.name
    let price= frmObj.price
   let  bought=frmObj.bought;
   console.log(name +price + bought)
  this.postObject = {
    "itemname": name,
    "itemquantity":price,
    "itembought":bought
  }
  console.log(this.postObject)
   this.naeService.postItem(this.postObject).subscribe(task=>{
    
    alert("added Successfully") });
  }
}
