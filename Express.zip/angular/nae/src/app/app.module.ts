import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GetItemsComponent } from './get-items/get-items.component';
import {HttpClientModule} from '@angular/common/http';
import { AddItemsComponent } from './add-items/add-items.component'
import {FormsModule} from '@angular/forms';
import { EditItemsComponent } from './edit-items/edit-items.component';
@NgModule({
  declarations: [
    AppComponent,
    GetItemsComponent,
    AddItemsComponent,
    EditItemsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
