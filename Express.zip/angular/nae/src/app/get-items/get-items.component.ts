import { Component, OnInit } from '@angular/core';
import { NaeService } from '../services/nae.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-get-items',
  templateUrl: './get-items.component.html',
  styleUrls: ['./get-items.component.css']
})
export class GetItemsComponent implements OnInit {

  constructor(private naeService:NaeService,private router:Router) { }

  items:any = []

  ngOnInit() {
    this.getItems()
  }

  getItems(){
    this.naeService.getItems().subscribe(displayItems =>this.items = displayItems)
  }

  deleteItems(id){
    if(confirm("Are you sure you want to delete?"))
    this.naeService.delteItem(id).subscribe(()=> this.getItems())
    alert("Deleted Successfully");


  }

  

}
