module.exports = {
  mongoURL: "mongodb+srv://psjc:psjc@cluster0-sid6s.mongodb.net/test?retryWrites=true"
}