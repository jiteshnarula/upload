import React, { Component } from 'react'
import NavigationComponent from './NavigationComponent';
import FooteComponent from './FooterComponent';

export default class LandingComponent extends Component {
    myStyle={ 
        position: "absolute",
        bottom: 0,
        padding: "1rem",
        width: "100%"
     }
  render() {
    return (
        <div>
        <NavigationComponent/>
      <div className="container">
        <div className="row">
            <div className="col-lg-6 display-1 text-success">
                Welcome to your professional Community     
            </div>

            <div className="col-lg-5">
                <img height="450" width="600" src={require("../../assets/landinpageimage2.jpg")}/>
            </div>
        </div>
      </div> 
      <div style={this.myStyle}>
        <FooteComponent/>
        </div>
      </div>
    )
  }
}
