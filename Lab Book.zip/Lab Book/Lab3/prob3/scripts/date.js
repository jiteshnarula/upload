function dateObject(){

    var d = new Date();
    var greet = "";
    document.getElementById("date").innerHTML=d;
    if(d.getHours() <12){

        greet = "Good Morning";
    }else if(d.getHours()>=12 && d.getHours<=17){
        greet = "Good Afternoon";
    } else{
        greet = "Good Evening";
    }

    document.getElementById("greet").innerHTML=greet;
    
}