function indexOfString(){
    var actualString= "University at Capgemini";
    var n = actualString.match("Capgemini");
    document.getElementById("result1").innerHTML = n;

    var result2 = actualString.substr(3,6);
    document.getElementById("result2").innerHTML = result2;

    var result3 = actualString.toLowerCase();
    document.getElementById("result3").innerHTML = result3;

    var result4 = actualString.toUpperCase();
    document.getElementById("result4").innerHTML = result4;
    
}