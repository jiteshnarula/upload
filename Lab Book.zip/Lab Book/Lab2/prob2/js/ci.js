function CI(){

    var p=1000;
    var r=10;
    var n=1;
    var ci;

    var ci = (p*Math.pow((1+ r/100),n))-p;


    document.getElementById("result").innerHTML=ci;


}

