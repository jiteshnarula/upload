function count(){

    var i=0;
    var count =0;
    while(i<100){
        count++; 
       
        if(count%10 == 0 ){
            document.getElementById("countHere").innerHTML+=""+i+"</br>";      
        }else{
            document.getElementById("countHere").innerHTML+=""+i+" ";
        }

        i++;
    }

}