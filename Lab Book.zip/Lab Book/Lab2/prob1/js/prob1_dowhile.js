function count(){
    var count=0;
   
    var i=0;
    var count=0;

    do{

        document.getElementById("countHere").innerHTML += i+" ";
        count++;
        if(count%10  == 0){
            document.getElementById("countHere").innerHTML += i +"<br/>";
            
        }
        i++;


    }while(i<100);

}
 
    