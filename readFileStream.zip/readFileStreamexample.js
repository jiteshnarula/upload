const http = require('http');
 const fs  =require('fs');
var readableStream= fs.createReadStream('./readFileStream.txt','utf8')
var writeableStream = fs.createWriteStream('./writeFileStream.txt'); 

//duplex
readableStream.pipe(writeableStream)


readableStream.on('data',(chunks)=>{
    // console.log('chunk is received')
    // console.log(chunks)
    
    writeableStream.write(chunks)
    /*
    
3types
1.readable 
2.writeable
3.duplex    */

    // console.log(chunks)

})

 