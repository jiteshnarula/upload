function localData(){
 
     
    var address = localStorage.getItem("address");
    var username = localStorage.getItem("username");

    var city = localStorage.getItem("city");
    
    var email = localStorage.getItem("email");
    
    var password = localStorage.getItem("password");

    sessionStorage.setItem("address",address);
    sessionStorage.setItem("username",username);
    sessionStorage.setItem("city",city);
    sessionStorage.setItem("email",email);
    sessionStorage.setItem("password",password);
 

    alert(sessionStorage.getItem("address"));
    document.getElementById("username").innerHTML=
    "Username="+sessionStorage.getItem("address");

    document.getElementById("address").innerHTML=
    "Address="+sessionStorage.getItem("address");

    document.getElementById("city").innerHTML=
    "City="+sessionStorage.getItem("city");

    document.getElementById("email").innerHTML=
    "Email="+sessionStorage.getItem("email");

    document.getElementById("password").innerHTML=
    "Password="+sessionStorage.getItem("password");


    document.getElementById("name").innerHTML="Welcome "+localStorage.getItem("username");
    
}
