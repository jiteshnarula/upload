function save(form){
    var username = form.textUN.value;
    var password = form.textPWD.value;
    var email = form.textEmail.value;
    var address = form.textAddress.value;
    var city = form.textCity.value;

    localStorage.setItem("username",username);
    localStorage.setItem("password",password);
    localStorage.setItem("email",email);
    localStorage.setItem("address",address);
    localStorage.setItem("city",city);

    
    window.open("file:///C:/Users/JiteshNarula/Desktop/HTML%20LAB/problem8%20local%20storage/pages/after.html","_self"); 
}
