function onSubmit(frm){
    var qty1 = frm.txtQty1.value;
    var qty2 = frm.txtQty2.value;
    var qty3 = frm.txtQty3.value;
    var qty4 = frm.txtQty4.value;
    var array = [];

    if((qty1=="" && qty2 =="" && qty3=="" && qty4=="")){
            alert("please enter something in the textbox");
    }

    if(isNaN(qty1) || isNaN(qty2) || isNaN(qty3) || isNaN(qty4)){
        alert("Invalid Input")
    }

    if(qty1 != ""){

        var localArray=[];
        localArray[0] = "Barbie Doll";
        localArray[1] = "Beautiful";
        localArray[2] = 20;
        localArray[3] = qty1;
        array.push(localArray);
    }

    if(qty2 != ""){
        var localArray=[];
        localArray[0] = "Calculator";
        localArray[1] = "Calculator with latest features";
        localArray[2] = 30;
        localArray[3] = qty2;
        array.push(localArray);
    }
    if(qty3 != ""){
        var localArray=[];
        localArray[0] = "Mobile Phone";
        localArray[1] = "Java Games";
        localArray[2] = 40;
        localArray[3] = qty3;
        array.push(localArray);
    }
    if(qty3 != ""){
        var localArray=[];
        localArray[0] = "LG DVD";
        localArray[1] = "5 disc changer";
        localArray[2] = 50;
        localArray[3] = qty4;
        array.push(localArray);
    }

    document.write(array);

    var finalResult = window.open("","Invoice window","Width=700,height=500");

    
    finalResult.document.write(`
    
                <html>
                <head>
                <title> Invoice Window</title>
                </head>

                <body>
                    <table>
                        <tr>
                            <th>Name</th>
                            <th>Description</th>
                            <th> Price </th>
                            <th> Qty </th>
                        </tr>
`);

                for(var i of array ){
                            var x = ` 
                        <tr>
                        <td>${i[0]}</td>
                        <td>${i[1]}</td>
                        <td>${i[2]}</td>
                        <td>${i[3]}</td>
                        <tr>`
                    finalResult.document.write(x);
   
                }

                finalResult.document.write(`
               
                    </table>

                </body>
                
                </html>

    `);
    }

    
