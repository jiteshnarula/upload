function newWindow(){
   var win =  window.open("","NewWindow","Resizeable,width=400,height=200");

   win.document.write("This window is opened by clicking on a New Window Button");
}