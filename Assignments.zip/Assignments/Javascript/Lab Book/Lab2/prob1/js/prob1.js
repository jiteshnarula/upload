function count(){
    var count=0;
    for(var i =0; i<100; i++){
        console.log(i);
        
             count++;
             if(count % 10 ==0){
                document.getElementById("countHere").innerHTML += i+"</br>";
           
             }else{
                document.getElementById("countHere").innerHTML += i+ " ";
                 
             }
  

        
    }
}
 
    