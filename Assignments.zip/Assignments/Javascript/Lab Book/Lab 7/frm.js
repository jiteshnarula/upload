function textBoxValidation(frm){

    
    var txt = parseInt(frm.txtVal.value);
 

    if(txt>=7 && txt<=15){
        document.getElementById("error").innerHTML="Value must not be between 7 and 15";
    }
}


function compute(frm){
  
    var a= frm.txt1.value;
    var b = frm.txt2.value;
    var c = frm.txtVal.value;
    alert(a);
    alert(b);
    alert(c);

    frm.txt4.value = a;
    frm.txt5.value = b;
    frm.txt6.value = c;
    


}