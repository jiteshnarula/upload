function indexOfString(){
    var actualString= "Capgemini";
    var n = actualString.indexOf("p"); 
    document.getElementById("result").innerHTML = n;
}