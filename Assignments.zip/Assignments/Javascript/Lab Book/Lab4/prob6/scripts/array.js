function arrayFunction(){
    var names = ["Tove","Hove","Stale","Kai Jam","Borge","undefined"];
    
    for(let i=0;i<names.length;i++){

        
    document.getElementById("result").innerHTML+= i+1 +". "+names[i]+"<br/>";
    }
    
}