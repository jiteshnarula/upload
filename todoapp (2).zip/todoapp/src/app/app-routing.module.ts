import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListtaskComponent } from './components/listtask/listtask.component';
import { EditComponent } from './components/edit/edit.component';

const routes: Routes = [
  {path:'', redirectTo:"/listtask",pathMatch:"full"},
  {path:"listtask",component:ListtaskComponent},
  {path:"app-edit/:id",component:EditComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
