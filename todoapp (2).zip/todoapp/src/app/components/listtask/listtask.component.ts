import { Component, OnInit } from '@angular/core';
import {TasksService} from '../../../services/tasks.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-listtask',
  templateUrl: './listtask.component.html',
  styleUrls: ['./listtask.component.css']
})
export class ListtaskComponent implements OnInit {
  

  task:object=[];
  constructor(private taskService: TasksService,private http:HttpClient) { }

  ngOnInit() {
    this.getTasksInComponent();
  }

  getTasksInComponent(){
    this.taskService.getTaskList().subscribe(allTasks=> this.task = allTasks);
  }

  deleteTask(id:number){
      this.taskService.deleteTask(id).subscribe(()=>this.getTasksInComponent());
  }
}
