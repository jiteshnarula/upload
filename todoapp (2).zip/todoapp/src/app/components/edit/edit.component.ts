import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';
import {HttpClient}  from '@angular/common/http';
import { TasksService } from 'src/services/tasks.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  id:number;
  taskList:any=[];
  matchedTask:object={};
  taskObject:object={};

  constructor(private http:HttpClient,private router:Router,
    private activatedRoute : ActivatedRoute,private taskService: TasksService) { }

  ngOnInit() {
  this.activatedRoute.params.subscribe(params => this.id = +params['id']);
    
  this.taskList = this.taskService.getTaskList()

  for(let i =0;i<this.taskList.length;i++){
    if(parseInt(this.taskList[i].id) === this.id){
      this.matchedTask = this.taskList[i];
    }
  }
}

updateTask(task){
  this.taskObject={
    "name" : task.taskname,
    "description" : task.taskdescription
  };

  this.taskService.updateTask(this.taskObject,this.id).subscribe(()=>{this.router.navigate['/listtask']});
}



}
